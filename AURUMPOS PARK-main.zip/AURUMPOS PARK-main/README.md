# 🚗 Sistema de Administración de Estacionamientos - EasyPark

## 📝 Descripción
Este proyecto es un sistema de administración de estacionamientos que permite gestionar el ingreso, salida y facturación de vehículos de manera automática. Se registra el tipo de vehículo, el tiempo de permanencia y el costo a pagar según reglas de negocio establecidas. Además, ofrece una interfaz de administración para gestionar tarifas y disponibilidad.

## ✨ Características principales
- 🎫 Registro automático de ingreso con generación de ticket.
- 💰 Cálculo del costo basado en el tiempo de estadía.
- 🅿️ Control de disponibilidad de espacios por tipo de vehículo.
- 🛠️ Panel de administración para gestionar tarifas y espacios.
- 🔍 Validación de datos para evitar sobreocupación.

## 🖥️ Tecnologías utilizadas
- ![ASP.NET Core](https://img.shields.io/badge/ASP.NET%20Core-512BD4?style=for-the-badge&logo=.net&logoColor=white) 
- ![SQL Server](https://img.shields.io/badge/SQL%20Server-CC2927?style=for-the-badge&logo=microsoft-sql-server&logoColor=white) 
- ![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white) 
- ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white) 
- ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black) 

## 🚀 Instalación y ejecución
1. 📥 Clonar el repositorio:
   ```bash
   git clone https://github.com/chrisfelixgil/easypark.git
   ```

## 🛠️ Uso
1. **🅿️ Ingreso:** Seleccionar el tipo de vehículo y presionar el botón de ingreso.
2. **🚗 Salida:** Ingresar el código del ticket para calcular el costo.
3. **🔧 Administración:** Acceder con credenciales para gestionar tarifas y disponibilidad.

## 🤝 Mejoras y contribución
Si deseas contribuir, puedes:
- 🐛 Reportar errores y sugerencias en Issues.
- ✨ Crear Pull Requests con mejoras.
- 📚 Ampliar la documentación.

## 👤 Autor
- **Nombre:** Christian Gil
- **Email:** christiangil2705@gmail.com
- **LinkedIn:** [Christian Gil](https://www.linkedin.com/in/christianfgilc/) 🔗💼

## 📜 Licencia
Este proyecto está bajo la licencia **MIT License** 📄, lo que significa que puedes utilizarlo, modificarlo y distribuirlo libremente.