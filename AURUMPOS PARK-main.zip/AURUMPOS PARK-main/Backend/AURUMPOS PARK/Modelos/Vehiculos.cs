﻿namespace EasyPark.Modelos
{
    public class Vehiculos
    {
        public int Id { get; set; }
        public string? TipoVehiculo { get; set; }
    }
}
