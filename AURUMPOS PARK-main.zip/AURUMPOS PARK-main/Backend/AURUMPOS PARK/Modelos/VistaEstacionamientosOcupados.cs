﻿namespace EasyPark.Modelos
{
    public class VistaEstacionamientosOcupados
    {
        public int IdEstacionamiento { get; set; }
        public string? TipoVehiculo { get; set; }
        public DateTime? FechaHoraIngreso { get; set; }

    }
}
