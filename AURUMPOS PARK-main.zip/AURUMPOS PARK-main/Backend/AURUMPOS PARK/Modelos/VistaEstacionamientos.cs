﻿namespace EasyPark.Modelos
{
    public class VistaEstacionamientos
    {
        public int IdEstacionamiento { get; set; }
        public string? TipoVehiculo { get; set; }
        public int CapacidadTotal { get; set; }
        public int EspacioOcupado { get; set; }
    }
}
