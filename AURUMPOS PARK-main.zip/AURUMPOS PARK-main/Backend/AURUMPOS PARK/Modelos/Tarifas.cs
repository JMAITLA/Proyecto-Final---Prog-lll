﻿namespace EasyPark.Modelos
{
    public class Tarifas
    {
        public int Id { get; set; }
        public int id_vehiculo { get; set; }
        public decimal Tarifa_por_hora { get; set; }
    }
}
