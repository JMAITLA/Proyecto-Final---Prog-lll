﻿namespace EasyPark.Modelos
{
    public class Estacionamientos
    {
        public int Id { get; set; }
        public int id_vehiculo { get; set; }
        public int CapacidadTotal { get; set; }
        public int EspacioOcupado { get; set; }
    }
}
