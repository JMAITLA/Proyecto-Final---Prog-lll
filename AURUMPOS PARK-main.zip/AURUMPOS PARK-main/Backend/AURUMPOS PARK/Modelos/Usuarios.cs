﻿namespace EasyPark.Modelos
{
    public class Usuarios
    {
        public int Id { get; set; }
        public string nombreUsuario { get; set; }
        public string contrasena { get; set; }
    }
}
